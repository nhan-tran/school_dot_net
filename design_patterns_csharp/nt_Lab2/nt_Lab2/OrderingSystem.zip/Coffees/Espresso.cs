using System;
using System.Configuration;

namespace nt_Lab2.Coffees
{
    /// <summary>
    /// Summary description for Espresso.
    /// </summary>
    public class Espresso : Beverage
    {
        public override double Cost
        {
            get { return GetSize(base.Size); }
        }

        public override string Description
        {
            get { return "Espresso"; }
        }

        private double GetSize(BeverageSize size)
        {
            switch (size)
            {
                case BeverageSize.Tall:
                    return Convert.ToDouble(ConfigurationManager.AppSettings["EspressoSizeTall"]);
                case BeverageSize.Grande:
                    return Convert.ToDouble(ConfigurationManager.AppSettings["EspressoSizeGrande"]);
                case BeverageSize.Venti:
                    return Convert.ToDouble(ConfigurationManager.AppSettings["EspressoSizeVenti"]);
                default:
                    return 1.50;
            }
        }
    }
}
