namespace nt_Lab2.Coffees
{
    /// <summary>
    /// Summary description for BeverageSize Enumerator.
    /// </summary>
    public enum BeverageSize
    {
        Tall,
        Grande,
        Venti
    }
}
