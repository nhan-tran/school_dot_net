namespace nt_Lab2.Coffees
{
    /// <summary>
    /// Summary description for CondimentDecorator.
    /// </summary>
    public abstract class CondimentDecorator : Beverage
    {
    }
}
