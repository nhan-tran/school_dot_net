using System;
using System.Configuration;

namespace nt_Lab2.Coffees
{
    /// <summary>
    /// Summary description for Mocha.
    /// </summary>
    public class Mocha : CondimentDecorator
    {
        Beverage beverage;

        public Mocha(Beverage beverage)
        {
            this.beverage = beverage;
        }

        public override double Cost
        {
            get { return GetSize(base.Size); }
        }

        public override string Description
        {
            get { return beverage.Description + ", Mocha"; }
        }

        private double GetSize(BeverageSize size)
        {
            double sizeCost = 0.20;
            switch (size)
            {
                case BeverageSize.Tall:
                    sizeCost = Convert.ToDouble(ConfigurationManager.AppSettings["MochaSizeTall"]);
                    break;
                case BeverageSize.Grande:
                    sizeCost = Convert.ToDouble(ConfigurationManager.AppSettings["MochaSizeGrande"]);
                    break;
                case BeverageSize.Venti:
                    sizeCost = Convert.ToDouble(ConfigurationManager.AppSettings["MochaSizeVenti"]);
                    break;
            }

            return this.beverage.Cost + sizeCost;
        }
    }
}
