﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using nt_Lab2.OrderingSystem;


namespace nt_Lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            OrderSystem o = OrderSystem.Instance;

            //initial salesTotal is 0
            Console.WriteLine(o.SalesTotal);

            o.SalesTotal += o.PlaceOrder("cheese", "clam");


            Console.WriteLine("Final total: " + o.SalesTotal);
            Console.ReadLine();
        }
    }
}
