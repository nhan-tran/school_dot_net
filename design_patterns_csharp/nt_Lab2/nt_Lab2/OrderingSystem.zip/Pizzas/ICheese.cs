namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for ICheese.
    /// </summary>
    public interface ICheese
    {
    }
}
