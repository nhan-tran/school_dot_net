namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for BlackOlives.
    /// </summary>
    public class BlackOlives : IVeggie
    {
        public override string ToString()
        {
            return "Black Olives";
        }
    }
}
