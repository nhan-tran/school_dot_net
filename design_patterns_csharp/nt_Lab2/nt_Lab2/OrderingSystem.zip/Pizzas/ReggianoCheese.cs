namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for ReggianoCheese.
    /// </summary>
    public class ReggianoCheese : ICheese
    {
        public override string ToString()
        {
            return "Reggiano Cheese";
        }
    }
}
