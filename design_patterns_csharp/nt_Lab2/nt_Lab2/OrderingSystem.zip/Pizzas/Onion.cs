namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for Onion.
    /// </summary>
    public class Onion : IVeggie
    {
        public override string ToString()
        {
            return "Onion";
        }
    }
}
