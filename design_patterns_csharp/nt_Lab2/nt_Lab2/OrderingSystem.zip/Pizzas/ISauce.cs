namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for ISauce.
    /// </summary>
    public interface ISauce
    {
    }
}
