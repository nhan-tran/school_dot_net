namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for MarinaraSauce.
    /// </summary>
    public class MarinaraSauce : ISauce
    {
        public override string ToString()
        {
            return "Marinara Sauce";
        }
    }
}
