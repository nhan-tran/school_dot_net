namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for IClams.
    /// </summary>
    public interface IClams
    {
    }
}
