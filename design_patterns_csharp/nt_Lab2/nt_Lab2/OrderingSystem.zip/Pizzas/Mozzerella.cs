namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for Mozzerella.
    /// </summary>
    public class Mozzerella : ICheese
    {
        public override string ToString()
        {
            return "Mozzerella Cheese";
        }
    }
}
