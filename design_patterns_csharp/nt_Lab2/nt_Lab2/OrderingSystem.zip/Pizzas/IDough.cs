namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for IDough.
    /// </summary>
    public interface IDough
    {
    }
}
