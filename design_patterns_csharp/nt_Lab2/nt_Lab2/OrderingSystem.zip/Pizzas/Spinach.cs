namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for Spinach.
    /// </summary>
    public class Spinach : IVeggie
    {
        public override string ToString()
        {
            return "Spinach";
        }
    }
}
