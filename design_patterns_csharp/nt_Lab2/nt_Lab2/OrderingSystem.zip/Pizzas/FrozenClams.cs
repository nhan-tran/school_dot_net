namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for FrozenClams.
    /// </summary>
    public class FrozenClams : IClams
    {
        public override string ToString()
        {
            return "Frozen Clams";
        }
    }
}
