namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for Mushroom.
    /// </summary>
    public class Mushroom : IVeggie
    {
        public override string ToString()
        {
            return "Mushroom";
        }
    }
}
