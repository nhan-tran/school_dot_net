namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for PlumTomatoSauce.
    /// </summary>
    public class PlumTomatoSauce : ISauce
    {
        public override string ToString()
        {
            return "Plum Tomato Sauce";
        }
    }
}
