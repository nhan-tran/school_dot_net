namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for FreshClams.
    /// </summary>
    public class FreshClams : IClams
    {
        public override string ToString()
        {
            return "Fresh Clams";
        }
    }
}
