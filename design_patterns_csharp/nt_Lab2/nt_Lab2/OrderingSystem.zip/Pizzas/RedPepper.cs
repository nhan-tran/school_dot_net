namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for RedPepper.
    /// </summary>
    public class RedPepper : IVeggie
    {
        public override string ToString()
        {
            return "Red Pepper";
        }
    }
}
