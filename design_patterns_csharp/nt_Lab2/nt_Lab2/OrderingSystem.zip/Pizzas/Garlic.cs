namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for Garlic.
    /// </summary>
    public class Garlic : IVeggie
    {
        public override string ToString()
        {
            return "Garlic";
        }
    }
}
