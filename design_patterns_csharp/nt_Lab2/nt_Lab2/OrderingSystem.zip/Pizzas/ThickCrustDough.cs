namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for ThickCrustDough.
    /// </summary>
    public class ThickCrustDough : IDough
    {
        public override string ToString()
        {
            return "Thick Crust Dough";
        }
    }
}
