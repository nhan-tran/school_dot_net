namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for SlicedPepperoni.
    /// </summary>
    public class SlicedPepperoni : IPepperoni
    {
        public override string ToString()
        {
            return "Sliced Pepperoni";
        }
    }
}
