namespace nt_Lab2.Pizzas
{
    /// <summary>
    /// Summary description for EggPlant.
    /// </summary>
    public class EggPlant : IVeggie
    {
        public override string ToString()
        {
            return "Egg Plant";
        }
    }
}
